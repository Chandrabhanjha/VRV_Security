// function levelDashboardDropdown() {
//   var level = document.getElementById("levels");
//   level.style.display = level.style.display === "none" ? "block" : "none";
// }
// function level2DashboardDropdown() {
//   var leve = document.getElementById("level2");
//   leve.style.display = leve.style.display === "none" ? "block" : "none";
// }

function toggleDropdown(elementId) {
  var dropdown = document.getElementById(elementId);
  dropdown.style.display = dropdown.style.display === "none" ? "block" : "none";
  dropdown.classList.add("open");
}

// calender

// scroll
$(document).ready(function () {
  $("#toggle-btn").on("click", function () {
    $("#sidebar-menu").toggleClass("active");
  });
});
//  progessbar

// Chart options

const areaChartOptions = {
  series: [
    {
      name: "teacher",
      data: [45, 60, 75, 51, 42, 42, 25],
    },
    {
      name: "Student",
      data: [24, 48, 56, 32, 34, 52, 32],
    },
  ],
  chart: {
    height: 350,
    type: "area",
    toolbar: {
      show: false,
    },
  },
  colors: ["#4f35a1", "#70c4f4"],
  dataLabels: {
    enabled: false,
  },
  stroke: {
    curve: "smooth",
  },
  labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"],
  markers: {
    size: 0,
  },

  tooltip: {
    shared: true,
    intersect: false,
  },
};

// Render the Chart when the window is loaded
window.onload = function () {
  const areaChart = new ApexCharts(
    document.querySelector("#admin1-area"),
    areaChartOptions
  );
  areaChart.render();
};

// Chart options

document.addEventListener("DOMContentLoaded", function () {
  // Chart rendering code here
  const A_barChartOptions = {
    series: [
      {
        name: "Teacher",
        data: [45, 60, 75, 51, 42, 42, 25],
      },
      {
        name: "Student",
        data: [24, 48, 56, 32, 34, 52, 32],
      },
    ],
    chart: {
      height: 350,
      type: "bar",
      toolbar: {
        show: false,
      },
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: "55%",
        endingShape: "rounded",
      },
    },
    colors: ["#4f35a1", "#70c4f4"],
    dataLabels: {
      enabled: false,
    },
    stroke: {
      show: true,
      width: 2,
      colors: ["transparent"],
    },
    xaxis: {
      categories: ["Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug"],
    },
    yaxis: {
      title: {
        text: "$ (thousands)",
      },
    },
    tooltip: {
      y: {
        formatter: function (val) {
          return "$ " + val + " thousands";
        },
      },
    },
  };

  const A_barChart = new ApexCharts(
    document.querySelector("#admin2-area"),
    A_barChartOptions
  );
  A_barChart.render();
});

// sidebar toggle
document.getElementById("toggleBtn").addEventListener("click", function () {
  toggleSidebar();
});

document.getElementById("toggleBtn").addEventListener("click", function () {
  var sideNav = document.getElementById("sideNav");
  var sidebar = document.getElementById("sidebar-menu");
  var mainContent = document.getElementById("main");
  var header = document.getElementById("header");
  var logo = document.querySelector(".logo");
  var logoSmall = document.querySelector(".logo-small");
  var headerLeft = document.querySelector(".header-left");
  var sidebarTitle = document.querySelectorAll(".sidebar-title");
  var openDropdownEle = document.querySelectorAll(".open");

  if (sidebar.style.width === "250px" || sidebar.style.width === "") {
    sideNav.classList.remove("sidebar");
    sideNav.classList.add("sidebar-collapsed");
    sidebar.style.width = "259px";
    // mainContent.style.marginLeft = "130px";
    mainContent.classList.add("sidebar-main");

    logo.style.display = "none";
    logoSmall.style.display = "block";
    headerLeft.style.width = "100px";
    sidebarTitle.forEach(function (e) {
      e.classList.add("hide-elements");
    });
    openDropdownEle.forEach(function (ele) {
      ele.style.display = "none";
    });
  } else {
    sideNav.classList.remove("sidebar-collapsed");
    sideNav.classList.add("sidebar");
    sidebar.style.width = "250px";
    // mainContent.style.marginLeft = "250px";
    mainContent.classList.remove("sidebar-main");

    logo.style.display = "block";
    logoSmall.style.display = "none";
    headerLeft.style.width = "259px";
    sidebarTitle.forEach(function (e) {
      e.classList.remove("hide-elements");
    });
  }
});

var sideNav = document.getElementById("sideNav");
var toggleBtn = document.getElementById("toggleBtn");

sideNav.addEventListener("mouseenter", function () {
  var sidebarTitle = document.querySelectorAll(".sidebar-title");
  if (sideNav.classList.contains("sidebar-collapsed")) {
    sidebarTitle.forEach(function (e) {
      e.classList.remove("hide-elements");
    });
  }
});

sideNav.addEventListener("mouseleave", function () {
  var sidebarTitle = document.querySelectorAll(".sidebar-title");
  if (sideNav.classList.contains("sidebar-collapsed")) {
    sidebarTitle.forEach(function (e) {
      e.classList.add("hide-elements");
    });
  }
});

toggleBtn.addEventListener("click", function () {
  sideNav.classList.toggle("open");
});
// Mobile button/
document.getElementById("mobile_Btn").addEventListener("click", function () {
  toggleSidebar();
});

document.getElementById("mobile_Btn").addEventListener("click", function () {
  var sideNav = document.getElementById("sideNav");
  var sidebar = document.getElementById("sidebar-menu");
  var mainContent = document.getElementById("main");

  var sidebarTitle = document.querySelectorAll(".sidebar-title");
  var openDropdownEle = document.querySelectorAll(".open");

  if (sidebar.style.width === "250px" || sidebar.style.width === "") {
    sideNav.classList.remove("sidebar");
    sideNav.classList.add("sidebar-collapsed");
    sidebar.style.width = "259px";
    // mainContent.style.marginLeft = "259px";
  } else {
    sideNav.classList.remove("sidebar-collapsed");
    sideNav.classList.add("sidebar");
    sidebar.style.width = "250px";
  }
});

// zoombar

document
  .getElementById("zoom-out-button")
  .addEventListener("click", function (event) {
    event.preventDefault(); // Prevent the default behavior of the link

    if (document.body.style.zoom === "100%") {
      document.body.style.zoom = "70%"; // Zoom out to 50% (adjust as needed)
    } else {
      document.body.style.zoom = "100%"; // Zoom back to 100%
    }
  });

//  icon rotate

function toggleDashboardDropdown() {
  var dropdown = document.getElementById("dashboard-dropdown");
  var arrowIcon = document.querySelector(".submenu .menu-arrow");

  if (dropdown.style.display === "none") {
    dropdown.style.display = "block";
    arrowIcon.classList.add("rotate"); // Add rotation class
  } else {
    dropdown.style.display = "none";
    arrowIcon.classList.remove("rotate"); // Remove rotation class
  }
}
//  sidebar hover

const sidebar = document.getElementById("sideNav");

function openSidebar() {
  sidebar.classList.add("opened");
}

// Function to close the sidebar
function closeSidebar() {
  sidebar.classList.remove("opened");
}

sidebar.addEventListener("mouseenter", openSidebar);
sidebar.addEventListener("mouseleave", closeSidebar);
// dropdown on difference dropdown
