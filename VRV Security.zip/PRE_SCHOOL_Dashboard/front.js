document.addEventListener("DOMContentLoaded", function () {
  const showRegisterBtn = document.getElementById("show-register-btn");
  const showLoginLink = document.getElementById("show-login-link");
  const loginContainer = document.getElementById("login");
  const registerContainer = document.getElementById("register");
  const registerNav = document.getElementById("show-register-link");

  showRegisterBtn.addEventListener("click", function () {
    loginContainer.classList.add("hide");
    registerContainer.classList.remove("hide");
  });

  showLoginLink.addEventListener("click", function () {
    loginContainer.classList.remove("hide");
    registerContainer.classList.add("hide");
  });

  registerNav.addEventListener("click", function () {
    loginContainer.classList.add("hide");
    registerContainer.classList.remove("hide");
  });
});

// registration page

document
  .querySelector(".register-form")
  .addEventListener("submit", function (event) {
    event.preventDefault();
    const username = document.querySelector(
      '#register input[type="text"]'
    ).value;
    const regEmail = document.querySelector(
      '#register input[type="email"]'
    ).value;
    const regPassword = document.querySelector(
      '#register input[type="password"]'
    ).value;
    const agreeTerms = document.querySelector(
      '#register input[type="checkbox"]'
    ).checked;

    if (username && regEmail && regPassword && agreeTerms) {
      alert("Registration successful");
      window.location.href = "front.html";
    } else {
      alert("Please fill in all fields and agree to the terms");
    }
  });

// login page

function validateEmail(email) {
  // Regular expression for basic email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validateLogin(email, password, termsChecked) {
  // You can add more complex validation rules for email and password here if needed
  return validateEmail(email) && password.trim() !== "" && termsChecked; // Basic validation
}

document.addEventListener("DOMContentLoaded", function () {
  const loginForm = document.querySelector(".login-form");

  loginForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const emailInput = document.querySelector('input[type="email"]');
    const passwordInput = document.querySelector('input[type="password"]');
    const termsCheckbox = document.querySelector('input[type="checkbox"]');
    const email = emailInput.value;
    const password = passwordInput.value;
    const termsChecked = termsCheckbox.checked;

    if (validateLogin(email, password, termsChecked)) {
      // Assuming login is successful, you might want to perform actual authentication here
      alert("Login successful");
      window.location.href = "Home.html";
    } else {
      // Provide feedback to the user about invalid input
      if (!validateEmail(email)) {
        alert("Invalid email address. Please enter a valid email.");
        emailInput.focus();
      } else if (password.trim() === "") {
        alert("Invalid password. Please enter a non-empty password.");
        passwordInput.focus();
      } else {
        alert("Please agree to the terms and conditions.");
        termsCheckbox.focus();
      }
    }
  });
});
