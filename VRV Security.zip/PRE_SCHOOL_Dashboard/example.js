// for (let i = 0; i < 99; i++) {
//   console.log(i + 1);
// }
//Program to add First n natural numbers
// let sum = 0;
// let n = prompt("Enter the value of n");
// n = Number.parseInt(n);
// for (let i = 0; i < n; i++) {
//   sum += i + 1;
// }
// console.log("Sum of First" + n + "natural number is" + sum);
// let obj = {
//   harry: 90,
//   shubh: 45,
//   deeksha: 90,
//   shiv: 34,
//   chandra: 30,
// };

// for (let a in obj) {
//   console.log("Marks of " + a + " are " + obj[a]);
// }
// let sum = 0;
// let n = prompt("Enter the value of n");
// n = Number.parseInt(n);

// for (var i = 0; i < n; i++) {
//   sum += i + 1;
// }

// console.log("Sum of first " + n + "natural numbers is " + sum);
// // console.log(i);

//
// while loop

let a = prompt("Enter the value of n");
n = Number.parseInt(n);
let i = 0;
while (i < n) {
  console.log(i);
  i++;
}
