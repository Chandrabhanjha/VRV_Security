document.getElementById("toggleBtn").addEventListener("click", function () {
  var sideNav = document.getElementById("sideNav");
  var sidebar = document.getElementById("sidebar-menu");
  var mainContent = document.getElementById("main");
  var header = document.getElementById("header");
  var logo = document.querySelector(".logo");
  var logoSmall = document.querySelector(".logo-small");
  var headerLeft = document.querySelector(".header-left");
  var sidebarTitle = document.querySelectorAll("#sidebar-title");
  var openDropdownEle = document.querySelectorAll(".open");

  if (sidebar.style.width === "250px" || sidebar.style.width === "") {
    sideNav.classList.remove("sidebar");
    sideNav.classList.add("sidebar-collapsed");
    sidebar.style.width = "300px";
    mainContent.style.marginLeft = "130px";
    // header.style.marginLeft = "0";
    logo.style.display = "none";
    logoSmall.style.display = "block";
    headerLeft.style.width = "100px";
    sidebarTitle.forEach(function (e) {
      e.style.display = "none";
    });
    openDropdownEle.forEach(function (ele) {
      ele.style.display = "none";
    });
  } else {
    sideNav.classList.remove("sidebar-collapsed");
    sideNav.classList.add("sidebar");
    sidebar.style.width = "250px";
    mainContent.style.marginLeft = "250px";
    // header.style.marginLeft = "250px";
    logo.style.display = "block";
    logoSmall.style.display = "none";
    headerLeft.style.width = "259px";
    sidebarTitle.forEach(function (e) {
      e.style.display = "block";
    });
  }
});
var mini = true;

function toggleSidebar(open) {
  if (open) {
    console.log("opening sidebar");
    document.getElementById("sideNav").style.width = "100px";
    document.getElementById("main").style.marginLeft = "130px";
    mini = false;
  } else {
    console.log("closing sidebar");
    document.getElementById("sideNav").style.width = "259px";
    document.getElementById("main").style.marginLeft = "130px";
    mini = true;
  }
}
onmouseover = "toggleSidebar(true)";
onmouseout = "toggleSidebar(false)";

document.getElementById("toggleBtn").addEventListener("click", function () {
  var sideNav = document.getElementById("sideNav");
  var sidebar = document.getElementById("sidebar-menu");
  var mainContent = document.getElementById("main");
  var header = document.getElementById("header");
  var logo = document.querySelector(".logo");
  var logoSmall = document.querySelector(".logo-small");
  var headerLeft = document.querySelector(".header-left");
  var sidebarTitle = document.querySelectorAll("#sidebar-title");
  var openDropdownEle = document.querySelectorAll(".open");

  if (sidebar.style.width === "250px" || sidebar.style.width === "") {
    sideNav.classList.remove("sidebar");
    sideNav.classList.add("sidebar-collapsed");
    sidebar.style.width = "300px";
    mainContent.style.marginLeft = "130px";
    // header.style.marginLeft = "0";
    logo.style.display = "none";
    logoSmall.style.display = "block";
    headerLeft.style.width = "100px";
    sidebarTitle.forEach(function (e) {
      e.style.display = "none";
    });
    openDropdownEle.forEach(function (ele) {
      ele.style.display = "none";
    });
  } else {
    sideNav.classList.remove("sidebar-collapsed");
    sideNav.classList.add("sidebar");
    sidebar.style.width = "250px";
    mainContent.style.marginLeft = "250px";
    // header.style.marginLeft = "250px";
    logo.style.display = "block";
    logoSmall.style.display = "none";
    headerLeft.style.width = "259px";
    sidebarTitle.forEach(function (e) {
      e.style.display = "block";
    });
  }
});
ocument.getElementById("toggleBtn").addEventListener("click", function () {
  var sideNav = document.getElementById("sideNav");
  var sidebar = document.getElementById("sidebar-menu");
  var mainContent = document.getElementById("main");
  var header = document.getElementById("header");
  var logo = document.querySelector(".logo");
  var logoSmall = document.querySelector(".logo-small");
  var headerLeft = document.querySelector(".header-left");
  var sidebarTitle = document.querySelectorAll(".sidebar-title");
  var openDropdownEle = document.querySelectorAll(".open");

  if (sidebar.style.width === "250px" || sidebar.style.width === "") {
    sideNav.classList.remove("sidebar");
    sideNav.classList.add("sidebar-collapsed");
    sidebar.style.width = "259px";
    mainContent.style.marginLeft = "130px";

    logo.style.display = "none";
    logoSmall.style.display = "block";
    headerLeft.style.width = "100px";
    sidebarTitle.forEach(function (e) {
      e.classList.add("hide-elements");
    });
    openDropdownEle.forEach(function (ele) {
      ele.style.display = "none";
    });
  } else {
    sideNav.classList.remove("sidebar-collapsed");
    sideNav.classList.add("sidebar");
    sidebar.style.width = "250px";
    mainContent.style.marginLeft = "250px";

    logo.style.display = "block";
    logoSmall.style.display = "none";
    headerLeft.style.width = "259px";
    sidebarTitle.forEach(function (e) {
      e.classList.remove("hide-elements");
    });
  }
});

var sideNav = document.getElementById("sideNav");
var toggleBtn = document.getElementById("toggleBtn");

sideNav.addEventListener("mouseenter", function () {
  var sidebarTitle = document.querySelectorAll(".sidebar-title");
  if (sideNav.classList.contains("sidebar-collapsed")) {
    sidebarTitle.forEach(function (e) {
      e.classList.remove("hide-elements");
    });
  }
});

sideNav.addEventListener("mouseleave", function () {
  var sidebarTitle = document.querySelectorAll(".sidebar-title");
  if (sideNav.classList.contains("sidebar-collapsed")) {
    sidebarTitle.forEach(function (e) {
      e.classList.add("hide-elements");
    });
  }
});

toggleBtn.addEventListener("click", function () {
  sideNav.classList.toggle("open");
});

