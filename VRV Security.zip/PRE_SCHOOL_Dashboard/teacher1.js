// Chart options

const areaChartOptions = {
  series: [
    {
      name: "teacher",
      data: [45, 60, 75, 51, 42, 42, 25],
    },
    {
      name: "Student",
      data: [24, 48, 56, 32, 34, 52, 32],
    },
  ],
  chart: {
    height: 350,
    type: "area",
    toolbar: {
      show: false,
    },
  },
  colors: ["#4f35a1", "#70c4f4"],
  dataLabels: {
    enabled: false,
  },
  stroke: {
    curve: "straight",
  },
  labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"],
  markers: {
    size: 0,
  },

  tooltip: {
    shared: true,
    intersect: false,
  },
};

const areaChart = new ApexCharts(
  document.querySelector("#school-area"),
  areaChartOptions
);
areaChart.render();

// calender

document.addEventListener("DOMContentLoaded", function () {
  const calendarContainer = document.getElementById("calendar");
  const eventDetailsContainer = document.getElementById("event-details");

  // Sample events data (replace with your actual data)
  const eventsData = [
    {
      date: "2024-02-10",
      time: "08:00 - 09:00 am",
      subject: "Botany",
      description: "Lorem ipsum sit amet",
    },
    // Add more events as needed
  ];

  // Initialize the calendar
  const calendar = new FullCalendar.Calendar(calendarContainer, {
    // Your FullCalendar options go here
    initialView: "dayGridMonth",
    events: eventsData.map((event) => ({
      title: event.subject,
      start: event.date + "T" + event.time.split(" ")[0],
      end: event.date + "T" + event.time.split(" ")[2],
      description: event.description,
    })),
    eventClick: function (info) {
      // Display event details when an event is clicked
      const eventDetails = `
          <h3>${info.event.title}</h3>
          <p>${info.event.startStr}</p>
          <p>${info.event.description}</p>
        `;
      eventDetailsContainer.innerHTML = eventDetails;
    },
  });

  // Render the calendar
  calendar.render();
});

// scroll

//  progessbar

var CircleOptions = {
  series: [55],
  chart: {
    height: 250,
    type: "radialBar",
  },
  plotOptions: {
    radialBar: {
      hollow: {
        size: "70%",
      },
    },
  },
  labels: ["Lession Progess"],
};

var chart = new ApexCharts(document.querySelector("#circle"), CircleOptions);
chart.render();

// Chart options

// Check if areaChartOptions is already defined before declaring it
document.addEventListener("DOMContentLoaded", function () {
  // Chart rendering code here
  const A_barChartOptions = {
    series: [
      {
        name: "Teacher",
        data: [45, 60, 75, 51, 42, 42, 25],
      },
      {
        name: "Student",
        data: [24, 48, 56, 32, 34, 52, 32],
      },
    ],
    chart: {
      height: 350,
      type: "bar",
      toolbar: {
        show: false,
      },
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: "55%",
        endingShape: "rounded",
      },
    },
    colors: ["#4f35a1", "#70c4f4"],
    dataLabels: {
      enabled: false,
    },
    stroke: {
      show: true,
      width: 2,
      colors: ["transparent"],
    },
    xaxis: {
      categories: ["Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug"],
    },
    yaxis: {
      title: {
        text: "$ (thousands)",
      },
    },
    tooltip: {
      y: {
        formatter: function (val) {
          return "$ " + val + " thousands";
        },
      },
    },
  };

  const A_barChart = new ApexCharts(
    document.querySelector("#admin2-area"),
    A_barChartOptions
  );
  A_barChart.render();
});
