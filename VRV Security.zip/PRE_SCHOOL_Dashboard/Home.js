function toggleDropdown(elementId) {
  var dropdown = document.getElementById(elementId);
  dropdown.style.display = dropdown.style.display === "none" ? "block" : "none";
  dropdown.classList.add("open");
}

// calender

// scroll
$(document).ready(function () {
  $("#toggle-btn").on("click", function () {
    $("#sidebar-menu").toggleClass("active");
  });
});
//  progessbar

var options = {
  series: [80],
  chart: {
    height: 200,
    type: "radialBar",
  },
  plotOptions: {
    radialBar: {
      hollow: {
        size: "80%",
      },
    },
  },
  labels: ["lession"],
};

document.getElementById("toggleBtn").addEventListener("click", function () {
  var sideNav = document.getElementById("sideNav");
  var sidebar = document.getElementById("sidebar-menu");
  //   var mainContent = document.getElementById("main");
  var header = document.getElementById("header");
  var logo = document.querySelector(".logo");
  var logoSmall = document.querySelector(".logo-small");
  var headerLeft = document.querySelector(".header-left");
  var sidebarTitle = document.querySelectorAll(".sidebar-title");
  var openDropdownEle = document.querySelectorAll(".open");

  if (sidebar.style.width === "250px" || sidebar.style.width === "") {
    sideNav.classList.remove("sidebar");
    sideNav.classList.add("sidebar-collapsed");
    sidebar.style.width = "259px";

    mainContent.classList.add("sidebar-main");

    logo.style.display = "none";
    logoSmall.style.display = "block";
    headerLeft.style.width = "100px";
    sidebarTitle.forEach(function (e) {
      e.classList.add("hide-elements");
    });
    openDropdownEle.forEach(function (ele) {
      ele.style.display = "none";
    });
  } else {
    sideNav.classList.remove("sidebar-collapsed");
    sideNav.classList.add("sidebar");
    sidebar.style.width = "250px";
    // mainContent.style.marginLeft = "px";
    mainContent.classList.remove("sidebar-main");

    logo.style.display = "block";
    logoSmall.style.display = "none";
    headerLeft.style.width = "259px";
    sidebarTitle.forEach(function (e) {
      e.classList.remove("hide-elements");
    });
  }
});

var sideNav = document.getElementById("sideNav");
var toggleBtn = document.getElementById("toggleBtn");

sideNav.addEventListener("mouseenter", function () {
  var sidebarTitle = document.querySelectorAll(".sidebar-title");
  if (sideNav.classList.contains("sidebar-collapsed")) {
    sidebarTitle.forEach(function (e) {
      e.classList.remove("hide-elements");
    });
  }
});

sideNav.addEventListener("mouseleave", function () {
  var sidebarTitle = document.querySelectorAll(".sidebar-title");
  if (sideNav.classList.contains("sidebar-collapsed")) {
    sidebarTitle.forEach(function (e) {
      e.classList.add("hide-elements");
    });
  }
});

toggleBtn.addEventListener("click", function () {
  sideNav.classList.toggle("open");
});

document.getElementById("mobile_Btn").addEventListener("click", function () {
  var sideNav = document.getElementById("sideNav");
  var sidebar = document.getElementById("sidebar-menu");
  //   var mainContent = document.getElementById("main");
  // var overlay = document.querySelector("overlay");

  var sidebarTitle = document.querySelectorAll(".sidebar-title");
  var openDropdownEle = document.querySelectorAll(".open");

  if (sidebar.style.width === "250px" || sidebar.style.width === "") {
    sideNav.classList.remove("sidebar");
    sideNav.classList.add("sidebar-collapsed");
    sidebar.style.width = "259px";
    // overlay.style.display = "block"; // Display overlay
  } else {
    sideNav.classList.remove("sidebar-collapsed");
    sideNav.classList.add("sidebar");
    sidebar.style.width = "250px";
    // overlay.style.display = "none"; // Hide overlay
  }
});

// 990px with hover
var sideNav = document.getElementById("sideNav");
var toggleBtn = document.getElementById("mobile_Btn");

sideNav.addEventListener("mouseenter", function () {
  var sidebarTitle = document.querySelectorAll(".sidebar-title");
  if (sideNav.classList.contains("sidebar-collapsed")) {
    sidebarTitle.forEach(function (e) {
      e.classList.remove("hide-elements");
    });
  }
});

sideNav.addEventListener("mouseleave", function () {
  var sidebarTitle = document.querySelectorAll(".sidebar-title");
  if (sideNav.classList.contains("sidebar-collapsed")) {
    sidebarTitle.forEach(function (e) {
      e.classList.add("hide-elements");
    });
  }
});

// zoombar

document
  .getElementById("zoom-out-button")
  .addEventListener("click", function (event) {
    event.preventDefault();

    if (document.body.style.zoom === "100%") {
      document.body.style.zoom = "70%"; // Zoom out to 50% (adjust as needed)
    } else {
      document.body.style.zoom = "100%"; // Zoom back to 100%
    }
  });

//  icon rotate

function toggleDashboardDropdown() {
  var dropdown = document.getElementById("dashboard-dropdown");
  var arrowIcon = document.querySelector(".submenu .menu-arrow");

  if (dropdown.style.display === "none") {
    dropdown.style.display = "block";
    arrowIcon.classList.add("rotate"); // Add rotation class
  } else {
    dropdown.style.display = "none";
    arrowIcon.classList.remove("rotate"); // Remove rotation class
  }
}
//  sidebar hover

const sidebar = document.getElementById("sideNav");

function openSidebar() {
  sidebar.classList.add("opened");
}

// Function to close the sidebar
function closeSidebar() {
  sidebar.classList.remove("opened");
}

sidebar.addEventListener("mouseenter", openSidebar);
sidebar.addEventListener("mouseleave", closeSidebar);
// dropdown on difference dropdown
// mobile_toggle
var mob_btn = document.getElementById("mobile_Btn");
var log_c = document.getElementById("log_exc");
var display = 0;
function screenchanges() {
  if (main.style.width === "990px" || main.style.width === "") {
    mob_btn.style.display = "block";

    log_c.style.display = "block";
    display = 0;
  } else {
    mob_btn.style.display = "none";
    log_c.style.display = "none";
    display = 1;
  }
}
// pages changes
function openCity(evt, cityName) {
  var i, sidebar_main, tablinks;
  sidebar_main = document.getElementsByClassName("sidebar_main");
  for (i = 0; i < tabcontent.length; i++) {
    sidebar_main[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
