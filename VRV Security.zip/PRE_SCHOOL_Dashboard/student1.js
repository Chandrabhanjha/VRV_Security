// scroll

//  progessbar

var options = {
  series: [80],
  chart: {
    height: 200,
    type: "radialBar",
  },
  plotOptions: {
    radialBar: {
      hollow: {
        size: "80%",
      },
    },
  },
  labels: ["lession"],
};

var chart = new ApexCharts(document.querySelector("#chart"), options);
chart.render();

// Chart options

document.addEventListener("DOMContentLoaded", function () {
  const areaChartOptions = {
    series: [
      {
        name: "teacher",
        data: [45, 60, 75, 51, 42, 42, 25],
      },
      {
        name: "Student",
        data: [24, 48, 56, 32, 34, 52, 32],
      },
    ],
    chart: {
      height: 350,
      type: "area",
      toolbar: {
        show: false,
      },
    },
    colors: ["#4f35a1", "#70c4f4"],
    dataLabels: {
      enabled: false,
    },
    stroke: {
      curve: "smooth",
    },
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"],
    markers: {
      size: 0,
    },
    tooltip: {
      shared: true,
      intersect: false,
    },
  };

  const areaChart = new ApexCharts(
    document.querySelector("#student-area"),
    areaChartOptions
  );
  areaChart.render();
});

//  icon rotate

//  sidebar hover
